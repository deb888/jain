<p>A customer has scheduled an audit.Details are provided below :: </p>
<p>Scheduled on ::   {!! $date  !!}</p>
<p> Name ::   {!! $fname  !!} {!! $lname  !!}</p>
<p>Email id ::   {!! $email  !!}</p>
<p>Contact No ::   {!! $phone  !!}</p>
<p>Address ::   {!! $address  !!}</p>
<p> State ::   {!! $state  !!}</p>
<p>City::   {!! $city  !!}</p>
<p>Country ::   {!! $country  !!}</p>


