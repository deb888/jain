<p>{!! $mailContent  !!}</p>
