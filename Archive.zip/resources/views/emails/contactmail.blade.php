<p>Name Of Contact {!! $mailContent1  !!}</p>
<p>Phone {!! $mailContent2  !!}</p>
