<p>user name {!! $mailContent1  !!}</p>
<p>Password {!! $mailContent2  !!}</p>
