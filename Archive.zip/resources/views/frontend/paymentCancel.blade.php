@extends('frontend.master',['contactdata'=>$contactdata])
@section('content')
<section class="inner-page-header wow fadeInDown">
	<div class="container"><h1>Payment Has been cancelled</h1></div>
</section>
<div style="height:67px;"></div>
@stop()
