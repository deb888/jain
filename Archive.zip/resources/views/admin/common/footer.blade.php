<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; <?php echo date('Y'); ?>-<?php echo date('Y')+1; ?> <a href="http://emaniasolutions.com">emaniasolutions</a>.</strong> All rights reserved.
      </footer>