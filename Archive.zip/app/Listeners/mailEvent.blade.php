<?php 
<h1>This Is A Linked email {{$email}}</h1>
<p>{{ $link }}</p>





