<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class terms_and_conditions extends Model
{
    protected $table = 'terms_and_condition';
}
