<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblcms extends Model
{
    //
}
