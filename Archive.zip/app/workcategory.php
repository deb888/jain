<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class workcategory extends Model
{
    //
}
