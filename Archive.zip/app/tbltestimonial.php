<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbltestimonial extends Model
{
    //
}
