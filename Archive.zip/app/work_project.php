<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class work_project extends Model
{
    //
}
