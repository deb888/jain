<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class clientmodel extends Model
{
    protected $table = 'client';
}
