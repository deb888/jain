<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emailmodel extends Model
{
    protected $table = 'email_content';
}
