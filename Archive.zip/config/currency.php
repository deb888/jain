<?php

return [
    'curr' => '<img src="http://45.32.242.35/~sdlapp/assets/img/doller-icon.png">',
];